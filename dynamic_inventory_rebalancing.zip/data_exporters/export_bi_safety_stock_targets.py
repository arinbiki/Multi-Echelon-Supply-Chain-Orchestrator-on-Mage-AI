import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_safety_stock_targets(forecast_df, *args, **kwargs):
    """BI Materialization: Materializes dynamic safety stock target levels per store."""
    targets = forecast_df[['store_id', 'cluster_id', 'sku', 'lead_time_buffer_units']].copy()
    targets.rename(columns={'lead_time_buffer_units': 'dynamic_safety_stock_units'}, inplace=True)
    print(f"📊 [BI Materialization] Materialized Dynamic Safety Stock Targets ({len(targets)} rows).")
    return targets