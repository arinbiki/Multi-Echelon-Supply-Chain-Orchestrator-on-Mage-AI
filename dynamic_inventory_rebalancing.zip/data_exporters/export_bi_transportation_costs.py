import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_transportation_costs(transfer_df, *args, **kwargs):
    """BI Materialization: Materializes optimized transportation and freight spend ledger."""
    summary = transfer_df.groupby('source_warehouse').agg(
        total_transfer_orders=('transfer_quantity', 'count'),
        total_units_dispatched=('transfer_quantity', 'sum'),
        total_freight_spend=('total_freight_cost', 'sum')
    ).reset_index()
    print("📊 [BI Materialization] Materialized Transportation Cost Spend Ledger.")
    return summary