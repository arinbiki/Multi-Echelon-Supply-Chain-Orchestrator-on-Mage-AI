import hashlib
import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_wms_us_east(transfer_df, *args, **kwargs):
    """WMS API Integration: Stages transfer orders for regional DC_US_EAST with 2-phase commit."""
    east_orders = transfer_df[transfer_df['source_warehouse'] == 'DC_US_EAST'].copy()
    east_orders['idempotency_key'] = east_orders.apply(
        lambda r: hashlib.sha256(f"20261013_{r['sku']}_{r['source_warehouse']}_{r['dest_store']}".encode()).hexdigest(),
        axis=1
    )
    print(f"🚚 [WMS US-East API] Staged {len(east_orders)} transfer orders with two-phase commit verification.")
    return east_orders