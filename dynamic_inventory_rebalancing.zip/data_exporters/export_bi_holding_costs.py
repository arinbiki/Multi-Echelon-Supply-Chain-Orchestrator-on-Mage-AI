import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_holding_costs(transfer_df, *args, **kwargs):
    """BI Materialization: Computes warehouse inventory carrying & holding cost impact."""
    summary = pd.DataFrame([{
        'warehouse_holding_cost_reduced': round(transfer_df['transfer_quantity'].sum() * 0.12, 2),
        'capital_freed_up': round(transfer_df['transfer_quantity'].sum() * 14.50, 2),
        'currency': 'USD'
    }])
    print("📊 [BI Materialization] Materialized Inventory Carrying Cost Ledger.")
    return summary