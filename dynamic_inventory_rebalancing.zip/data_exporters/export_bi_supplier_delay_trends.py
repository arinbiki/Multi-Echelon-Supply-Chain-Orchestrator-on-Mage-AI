import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_supplier_delay_trends(supplier_leads, *args, **kwargs):
    """BI Materialization: Materializes Supplier Delay Trends and Groq fallback tracking."""
    records = list(supplier_leads.values())
    df = pd.DataFrame(records)
    print(f"📊 [BI Materialization] Materialized Supplier Delay Trends ({len(df)} supplier clusters).")
    return df