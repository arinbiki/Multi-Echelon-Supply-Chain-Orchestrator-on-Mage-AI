import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_sop_executive_summary(governance_telemetry, transfer_df, *args, **kwargs):
    """BI Materialization: Formats Multi-Stakeholder S&OP Executive Brief."""
    summary_report = f"""# 📦 S&OP EXECUTIVE BRIEF: INVENTORY REBALANCING & DEMAND FORECASTING
**Status**: {governance_telemetry['pipeline_status']} | **KL Drift**: {governance_telemetry['kl_divergence']}
**Total Transfer Orders**: {governance_telemetry['total_transfer_orders']}
**Total Units Rebalanced**: {governance_telemetry['total_units_rebalanced']:,}
**Optimized Freight Spend**: ${governance_telemetry['total_freight_spend_optimized']:,.2f}
**Stockout Penalties Avoided**: ${governance_telemetry['total_stockout_penalty_avoided']:,.2f}
**Net S&OP Cost Benefit**: ${governance_telemetry['net_cost_benefit']:,.2f}
**Cryptographic Audit Hash**: {governance_telemetry['cryptographic_audit_hash']}
"""
    print("📄 [Executive S&OP Brief] Successfully generated executive Markdown deliverable.")
    return summary_report