import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_transfer_orders(transfer_df, *args, **kwargs):
    """BI Materialization: Materializes Master Transfer Order Manifests."""
    print(f"📊 [BI Materialization] Materialized Master Transfer Order Manifest ({len(transfer_df)} dispatch orders).")
    return transfer_df