import hashlib
import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_wms_eu_central(transfer_df, *args, **kwargs):
    """WMS API Integration: Stages transfer orders for regional DC_EU_CENTRAL with 2-phase commit."""
    eu_orders = transfer_df[transfer_df['source_warehouse'] == 'DC_EU_CENTRAL'].copy()
    eu_orders['idempotency_key'] = eu_orders.apply(
        lambda r: hashlib.sha256(f"20261013_{r['sku']}_{r['source_warehouse']}_{r['dest_store']}".encode()).hexdigest(),
        axis=1
    )
    print(f"🚚 [WMS EU-Central API] Staged {len(eu_orders)} transfer orders with two-phase commit verification.")
    return eu_orders