import hashlib
import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_wms_us_west(transfer_df, *args, **kwargs):
    """WMS API Integration: Stages transfer orders for regional DC_US_WEST with 2-phase commit."""
    west_orders = transfer_df[transfer_df['source_warehouse'] == 'DC_US_WEST'].copy()
    west_orders['idempotency_key'] = west_orders.apply(
        lambda r: hashlib.sha256(f"20261013_{r['sku']}_{r['source_warehouse']}_{r['dest_store']}".encode()).hexdigest(),
        axis=1
    )
    print(f"🚚 [WMS US-West API] Staged {len(west_orders)} transfer orders with two-phase commit verification.")
    return west_orders