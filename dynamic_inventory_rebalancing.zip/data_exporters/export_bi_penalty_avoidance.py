import pandas as pd

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter

@data_exporter
def export_bi_penalty_avoidance(transfer_df, *args, **kwargs):
    """BI Materialization: Computes stockout penalty avoidance revenue savings."""
    summary = transfer_df.groupby('cluster_id').agg(
        total_units_saved=('transfer_quantity', 'sum'),
        stockout_penalty_avoided=('stockout_penalty_avoided', 'sum')
    ).reset_index()
    print(f"📊 [BI Materialization] Materialized Penalty Avoidance Savings ({len(summary)} clusters).")
    return summary