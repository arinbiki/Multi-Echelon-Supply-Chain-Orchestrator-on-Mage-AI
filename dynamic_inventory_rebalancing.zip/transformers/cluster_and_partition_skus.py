if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

@transformer
def cluster_and_partition_skus(sku_catalog, *args, **kwargs):
    """
    Phase 3: The Clustering Partitioner (Dynamic Block)
    Groups active catalog SKUs into 25 distinct product category clusters based on
    velocity, margin, and seasonality characteristics.
    Outputs a partitioned list of cluster dictionaries for parallel execution fanning.
    """
    clusters_def = [
        ('HV_ELEC', 'High-Velocity Electronics', 'HIGH', 'HIGH', 'LOW'),
        ('SEAS_APP', 'Seasonal Apparel & Outerwear', 'MEDIUM', 'HIGH', 'HIGH'),
        ('GROC_PERISH', 'Perishable Groceries', 'VERY_HIGH', 'LOW', 'MEDIUM'),
        ('HOME_GOODS', 'Home Furnishings', 'MEDIUM', 'MEDIUM', 'LOW'),
        ('AUTO_PARTS', 'Automotive Aftermarket', 'LOW', 'HIGH', 'LOW'),
        ('PHARMA_OTC', 'Over-The-Counter Pharma', 'HIGH', 'HIGH', 'LOW'),
        ('BEAUTY_PERS', 'Cosmetics & Personal Care', 'HIGH', 'HIGH', 'MEDIUM'),
        ('BEV_ALCOHOL', 'Beverages & Spirits', 'HIGH', 'MEDIUM', 'HIGH'),
        ('OFFICE_SUPP', 'Commercial Office Supplies', 'MEDIUM', 'MEDIUM', 'LOW'),
        ('SPORT_OUTDOOR', 'Sporting & Camping', 'MEDIUM', 'MEDIUM', 'HIGH'),
        ('TOYS_HOBBY', 'Toys & Board Games', 'MEDIUM', 'HIGH', 'VERY_HIGH'),
        ('PET_CARE', 'Pet Food & Healthcare', 'HIGH', 'MEDIUM', 'LOW'),
        ('FURN_BED', 'Furniture & Mattresses', 'LOW', 'HIGH', 'LOW'),
        ('BABY_CARE', 'Baby Essentials & Nutrition', 'HIGH', 'MEDIUM', 'LOW'),
        ('HARDWARE_TOOL', 'Power Tools & Hardware', 'LOW', 'HIGH', 'LOW'),
        ('JEWEL_ACC', 'Jewelry & Timepieces', 'LOW', 'VERY_HIGH', 'HIGH'),
        ('PACK_IND', 'Industrial Packaging', 'HIGH', 'LOW', 'LOW'),
        ('FOOTWEAR', 'Athletic Footwear', 'HIGH', 'HIGH', 'MEDIUM'),
        ('LUX_GOODS', 'Luxury Fashion', 'LOW', 'VERY_HIGH', 'MEDIUM'),
        ('GARDEN_PATIO', 'Lawn & Garden Care', 'MEDIUM', 'MEDIUM', 'HIGH'),
        ('DAIRY_PROD', 'Refrigerated Dairy & Eggs', 'VERY_HIGH', 'LOW', 'LOW'),
        ('FROZEN_FOODS', 'Frozen Prepared Foods', 'HIGH', 'LOW', 'LOW'),
        ('MEAT_SEAFOOD', 'Fresh Meat & Seafood', 'VERY_HIGH', 'MEDIUM', 'LOW'),
        ('PRODUCE_BULK', 'Bulk Produce & Fruit', 'VERY_HIGH', 'LOW', 'MEDIUM'),
        ('CLEAN_CHEM', 'Household Cleaners', 'HIGH', 'LOW', 'LOW')
    ]
    
    partitions = []
    for cid, cname, vel, mar, seas in clusters_def:
        skus_in_cluster = [f'SKU_{cid}_{i:02d}' for i in range(1, 5)]
        partitions.append({
            'cluster_id': cid,
            'cluster_name': cname,
            'velocity_tier': vel,
            'margin_tier': mar,
            'seasonality_level': seas,
            'active_skus': skus_in_cluster,
            'sku_count': len(skus_in_cluster)
        })
        
    print(f"📦 [Dynamic Partitioner] Synthesized {len(partitions)} distinct category clusters for parallel fanning.")
    return partitions