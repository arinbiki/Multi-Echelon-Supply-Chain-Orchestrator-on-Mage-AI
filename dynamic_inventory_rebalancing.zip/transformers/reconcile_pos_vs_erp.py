if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

@transformer
def reconcile_pos_vs_erp(pos_df, erp_df, *args, **kwargs):
    """
    Phase 2 Data Integrity Gate:
    Reconciles Point-of-Sale (POS) sales against Enterprise ERP ledger inventory deductions.
    Enforces a strict variance tolerance threshold of <= 0.5%.
    Halts the pipeline immediately if data integrity fails.
    """
    total_pos_units = float(pos_df['units_sold'].sum())
    total_erp_units = float(erp_df['erp_units_deducted'].sum())
    
    variance = abs(total_pos_units - total_erp_units) / max(total_erp_units, 1.0)
    variance_pct = variance * 100.0
    
    print(f"🔍 [Data Integrity Gate] Total POS Units: {total_pos_units:,.0f} | Total ERP Units: {total_erp_units:,.0f}")
    print(f"🔍 [Data Integrity Gate] Discrepancy Variance: {variance_pct:.4f}% (Threshold: <= 0.50%)")
    
    if variance > 0.005:
        raise ValueError(
            f"❌ [DATA CORRUPTION DETECTED] POS vs ERP reconciliation variance ({variance_pct:.4f}%) "
            f"exceeds strict threshold (0.50%). Halting downstream execution to prevent corrupted forecasts."
        )
    
    return {
        'reconciliation_status': 'PASSED',
        'variance_pct': variance_pct,
        'total_pos_units': total_pos_units,
        'total_erp_units': total_erp_units,
        'timestamp': pos_df['mage_ingestion_timestamp'].iloc[0] if 'mage_ingestion_timestamp' in pos_df else None
    }