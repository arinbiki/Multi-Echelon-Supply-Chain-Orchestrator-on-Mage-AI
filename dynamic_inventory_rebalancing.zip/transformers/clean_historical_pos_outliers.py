import numpy as np
import pandas as pd

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

@transformer
def clean_historical_pos_outliers(clusters, pos_df, *args, **kwargs):
    """
    Phase 4B: Category-Specific Outlier Cleaning
    Detects statistical anomalies and bulk wholesale purchases in historical POS transactions.
    Applies Tukey's Interquartile Range (IQR) capping at Q3 + 1.5 * IQR.
    """
    cleaned_pos = pos_df.copy()
    cleaned_records = []
    
    for part in clusters:
        cid = part['cluster_id']
        c_pos = cleaned_pos[cleaned_pos['cluster_id'] == cid]
        if len(c_pos) == 0:
            continue
            
        q1 = c_pos['units_sold'].quantile(0.25)
        q3 = c_pos['units_sold'].quantile(0.75)
        iqr = q3 - q1
        upper_limit = q3 + 1.5 * iqr
        
        # Cap outlier bulk sales
        c_pos['units_sold_cleaned'] = c_pos['units_sold'].clip(upper=upper_limit)
        cleaned_records.append(c_pos)
        
    final_df = pd.concat(cleaned_records, ignore_index=True) if cleaned_records else cleaned_pos
    print(f"🧹 [Outlier Cleaning] Normalized POS volume across {len(final_df)} records.")
    return final_df