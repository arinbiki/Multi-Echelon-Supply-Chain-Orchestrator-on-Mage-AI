import pandas as pd

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

@transformer
def engineer_category_features(cleaned_pos, weather_df, promo_df, macro_df, *args, **kwargs):
    """
    Phase 4B: Hyper-Local Feature Engineering
    Computes category-specific feature sets: weather sensitivity, promotional lag,
    promotional decay rates, and velocity momentum.
    """
    # Compute store-cluster velocity aggregations
    grouped = cleaned_pos.groupby(['store_id', 'cluster_id', 'sku']).agg(
        avg_units=('units_sold_cleaned', 'mean'),
        std_units=('units_sold_cleaned', 'std'),
        total_units=('units_sold_cleaned', 'sum')
    ).reset_index()
    grouped['std_units'] = grouped['std_units'].fillna(2.5)
    
    # Merge promotional uplift factor
    promo_map = dict(zip(promo_df['cluster_id'], promo_df['discount_pct']))
    grouped['promo_discount_pct'] = grouped['cluster_id'].map(promo_map).fillna(0.0)
    grouped['promo_decay_factor'] = grouped['promo_discount_pct'].apply(lambda d: 1.0 + (d * 0.015))
    
    # Merge weather sensitivity
    avg_temp_delta = float(weather_df['temp_delta_baseline'].mean())
    grouped['weather_sensitivity'] = grouped['cluster_id'].apply(
        lambda c: 1.12 if c in ['SEAS_APP', 'GARDEN_PATIO', 'BEV_ALCOHOL'] and avg_temp_delta > 0 else 1.0
    )
    
    # Feature vector: expected daily demand baseline
    grouped['engineered_daily_baseline'] = (
        grouped['avg_units'] * grouped['promo_decay_factor'] * grouped['weather_sensitivity']
    ).round(2)
    
    print(f"⚙️ [Feature Engineering] Engineered multi-factor feature vectors for {len(grouped)} SKU-store pairs.")
    return grouped