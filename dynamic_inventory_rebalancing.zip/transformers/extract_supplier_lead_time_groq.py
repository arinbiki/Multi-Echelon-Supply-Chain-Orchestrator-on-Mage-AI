import json
import urllib.request
import pandas as pd

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer

GROQ_API_KEY = "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"

@transformer
def extract_supplier_lead_time_groq(clusters, emails_df, supplier_history_df, *args, **kwargs):
    """
    Phase 4A: Groq API Supplier Lead-Time Extraction & Rollback Guardrails
    Processes unstructured procurement emails with strict JSON extraction,
    evaluates physical boundaries (delay <= 120 days, confidence >= 0.8),
    and triggers automated rollback to historical moving average if violated.
    """
    results = {}
    audit_logs = []
    
    # Process each cluster partition
    for part in clusters:
        cid = part['cluster_id']
        hist_row = supplier_history_df[supplier_history_df['cluster_id'] == cid]
        fallback_lead_time = int(hist_row['baseline_lead_time_days'].iloc[0]) if len(hist_row) > 0 else 14
        
        # Check matching emails
        matching_emails = emails_df[emails_df['cluster_hint'] == cid] if 'cluster_hint' in emails_df else pd.DataFrame()
        
        extracted_delay = 0
        reason = "Normal scheduled lead time"
        confidence = 0.95
        used_rollback = False
        
        if len(matching_emails) > 0:
            email_body = matching_emails['body'].iloc[0]
            # Call Groq API with deterministic JSON schema
            prompt = "Extract supplier delay for category " + str(cid) + " from: " + str(email_body) + ". Output strictly JSON: {\"sku_category\": \"" + str(cid) + "\", \"delay_days\": <int>, \"reason\": \"<str>\", \"confidence\": <float>}"
            try:
                url = "https://api.groq.com/openai/v1/chat/completions"
                payload = {
                    "model": "openai/gpt-oss-20b",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 150
                }
                req = urllib.request.Request(
                    url,
                    data=json.dumps(payload).encode('utf-8'),
                    headers={"Authorization": f"Bearer {GROQ_API_KEY}", "Content-Type": "application/json"},
                    method="POST"
                )
                with urllib.request.urlopen(req, timeout=5) as resp:
                    resp_data = json.loads(resp.read().decode('utf-8'))
                    raw_content = resp_data["choices"][0]["message"]["content"]
                    parsed = json.loads(raw_content)
                    
                    delay_candidate = int(parsed.get("delay_days", 0))
                    conf_candidate = float(parsed.get("confidence", 0.0))
                    
                    # PHYSICAL BOUNDARY & INTEGRITY GATE
                    if delay_candidate > 120 or conf_candidate < 0.8:
                        print(f"⚠️ [Rollback Triggered] Cluster {cid}: Delay ({delay_candidate}d) or confidence ({conf_candidate}) breached limits. Rolling back.")
                        extracted_delay = int(hist_row['moving_avg_delay_days'].iloc[0]) if len(hist_row) > 0 else 2
                        used_rollback = True
                        reason = f"Automated Rollback to Historical Baseline ({parsed.get('reason')})"
                    else:
                        extracted_delay = delay_candidate
                        confidence = conf_candidate
                        reason = parsed.get("reason", "Supplier Email Extract")
            except Exception as e:
                # Resilient fallback to moving average
                extracted_delay = int(hist_row['moving_avg_delay_days'].iloc[0]) if len(hist_row) > 0 else 2
                used_rollback = True
                reason = f"Heuristic Rule Fallback (LLM API: {str(e)[:50]})"
                
        results[cid] = {
            'cluster_id': cid,
            'baseline_lead_time_days': fallback_lead_time,
            'dynamic_lead_time_days': fallback_lead_time + extracted_delay,
            'delay_days': extracted_delay,
            'reason': reason,
            'confidence': confidence,
            'used_rollback': used_rollback
        }
        
    print(f"🤖 [Groq Supplier Intelligence] Extracted lead times across {len(results)} category clusters.")
    return results