import datetime
import numpy as np
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_pos_transactions(*args, **kwargs):
    """Ingests 100,000 store-level POS transaction records across 25 product category clusters."""
    N_RECORDS = 100_000
    clusters = [
        'HV_ELEC', 'SEAS_APP', 'GROC_PERISH', 'HOME_GOODS', 'AUTO_PARTS',
        'PHARMA_OTC', 'BEAUTY_PERS', 'BEV_ALCOHOL', 'OFFICE_SUPP', 'SPORT_OUTDOOR',
        'TOYS_HOBBY', 'PET_CARE', 'FURN_BED', 'BABY_CARE', 'HARDWARE_TOOL',
        'JEWEL_ACC', 'PACK_IND', 'FOOTWEAR', 'LUX_GOODS', 'GARDEN_PATIO',
        'DAIRY_PROD', 'FROZEN_FOODS', 'MEAT_SEAFOOD', 'PRODUCE_BULK', 'CLEAN_CHEM'
    ]
    stores = [f'STORE_{i:03d}' for i in range(1, 21)]
    base_date = datetime.date.today() - datetime.timedelta(days=1)
    
    np.random.seed(42)
    c_idx = np.random.randint(0, len(clusters), size=N_RECORDS)
    s_idx = np.random.randint(0, len(stores), size=N_RECORDS)
    sku_idx = np.random.randint(1, 5, size=N_RECORDS)
    
    c_arr = [clusters[i] for i in c_idx]
    s_arr = [stores[i] for i in s_idx]
    sku_arr = [f'SKU_{c_arr[i]}_{sku_idx[i]:02d}' for i in range(N_RECORDS)]
    
    units_arr = np.random.randint(15, 180, size=N_RECORDS)
    price_arr = np.round(np.random.uniform(9.5, 249.0, size=N_RECORDS), 2)
    rev_arr = np.round(units_arr * price_arr, 2)
    
    df = pd.DataFrame({
        'transaction_date': str(base_date),
        'store_id': s_arr,
        'cluster_id': c_arr,
        'sku': sku_arr,
        'units_sold': units_arr,
        'unit_price': price_arr,
        'revenue': rev_arr,
        'source_system': 'POS_STREAM_KAFKA',
        'mage_ingestion_timestamp': datetime.datetime.utcnow().isoformat()
    })
    print(f"📦 [POS Ingestion] Successfully ingested {len(df):,} synthetic real-time POS transactions.")
    return df
