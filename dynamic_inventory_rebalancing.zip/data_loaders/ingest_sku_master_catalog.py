import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_sku_master_catalog(*args, **kwargs):
    """Ingests SKU master attributes, physical dimensions, and cost structures."""
    clusters = [
        'HV_ELEC', 'SEAS_APP', 'GROC_PERISH', 'HOME_GOODS', 'AUTO_PARTS',
        'PHARMA_OTC', 'BEAUTY_PERS', 'BEV_ALCOHOL', 'OFFICE_SUPP', 'SPORT_OUTDOOR',
        'TOYS_HOBBY', 'PET_CARE', 'FURN_BED', 'BABY_CARE', 'HARDWARE_TOOL',
        'JEWEL_ACC', 'PACK_IND', 'FOOTWEAR', 'LUX_GOODS', 'GARDEN_PATIO',
        'DAIRY_PROD', 'FROZEN_FOODS', 'MEAT_SEAFOOD', 'PRODUCE_BULK', 'CLEAN_CHEM'
    ]
    skus = []
    for c in clusters:
        for idx in range(1, 5):
            sku_id = f'SKU_{c}_{idx:02d}'
            holding_cost_annual = 0.28 if 'ELEC' in c or 'LUX' in c else 0.18
            skus.append({
                'sku': sku_id,
                'cluster_id': c,
                'sku_name': f'{c} Commercial Unit {idx}',
                'unit_volume_m3': 0.045,
                'unit_weight_kg': 2.8,
                'unit_holding_cost_daily': round(120.0 * holding_cost_annual / 365.0, 4),
                'stockout_penalty_per_unit': round(120.0 * 0.45, 2)
            })
    return pd.DataFrame(skus)