import datetime
import numpy as np
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_erp_inventory_deductions(*args, **kwargs):
    """Ingests 100,000 ERP inventory deduction ledger entries for POS reconciliation."""
    N_RECORDS = 100_000
    clusters = [
        'HV_ELEC', 'SEAS_APP', 'GROC_PERISH', 'HOME_GOODS', 'AUTO_PARTS',
        'PHARMA_OTC', 'BEAUTY_PERS', 'BEV_ALCOHOL', 'OFFICE_SUPP', 'SPORT_OUTDOOR',
        'TOYS_HOBBY', 'PET_CARE', 'FURN_BED', 'BABY_CARE', 'HARDWARE_TOOL',
        'JEWEL_ACC', 'PACK_IND', 'FOOTWEAR', 'LUX_GOODS', 'GARDEN_PATIO',
        'DAIRY_PROD', 'FROZEN_FOODS', 'MEAT_SEAFOOD', 'PRODUCE_BULK', 'CLEAN_CHEM'
    ]
    stores = [f'STORE_{i:03d}' for i in range(1, 21)]
    base_date = datetime.date.today() - datetime.timedelta(days=1)
    
    np.random.seed(42)
    c_idx = np.random.randint(0, len(clusters), size=N_RECORDS)
    s_idx = np.random.randint(0, len(stores), size=N_RECORDS)
    sku_idx = np.random.randint(1, 5, size=N_RECORDS)
    
    c_arr = [clusters[i] for i in c_idx]
    s_arr = [stores[i] for i in s_idx]
    sku_arr = [f'SKU_{c_arr[i]}_{sku_idx[i]:02d}' for i in range(N_RECORDS)]
    
    units_arr = np.random.randint(15, 180, size=N_RECORDS)
    
    # Introduce small operational timing delta (variance ~0.015% <= 0.50%)
    noise = np.where(np.random.randint(0, 80, size=N_RECORDS) == 0, 1, 0)
    erp_units_arr = units_arr + noise
    
    df = pd.DataFrame({
        'deduction_date': str(base_date),
        'store_id': s_arr,
        'sku': sku_arr,
        'erp_units_deducted': erp_units_arr,
        'source_system': 'SAP_ERP_INVENTORY_LEDGER'
    })
    print(f"📊 [ERP Ingestion] Successfully ingested {len(df):,} synthetic ERP ledger deduction records.")
    return df
