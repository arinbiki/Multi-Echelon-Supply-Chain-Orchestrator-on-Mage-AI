import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_supplier_performance_history(*args, **kwargs):
    """Ingests historical supplier delivery metrics and baseline lead times."""
    clusters = [
        'HV_ELEC', 'SEAS_APP', 'GROC_PERISH', 'HOME_GOODS', 'AUTO_PARTS',
        'PHARMA_OTC', 'BEAUTY_PERS', 'BEV_ALCOHOL', 'OFFICE_SUPP', 'SPORT_OUTDOOR',
        'TOYS_HOBBY', 'PET_CARE', 'FURN_BED', 'BABY_CARE', 'HARDWARE_TOOL',
        'JEWEL_ACC', 'PACK_IND', 'FOOTWEAR', 'LUX_GOODS', 'GARDEN_PATIO',
        'DAIRY_PROD', 'FROZEN_FOODS', 'MEAT_SEAFOOD', 'PRODUCE_BULK', 'CLEAN_CHEM'
    ]
    data = []
    for c in clusters:
        base_lt = 21 if 'ELEC' in c or 'AUTO' in c else (3 if 'PERISH' in c or 'DAIRY' in c else 14)
        data.append({
            'cluster_id': c,
            'primary_supplier': f'SUP_{c}_CORP',
            'baseline_lead_time_days': base_lt,
            'historical_otif_pct': 94.5,
            'moving_avg_delay_days': 1.8
        })
    return pd.DataFrame(data)