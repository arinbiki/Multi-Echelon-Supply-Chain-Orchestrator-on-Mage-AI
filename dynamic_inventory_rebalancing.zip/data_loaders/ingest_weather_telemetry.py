import datetime
import random
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_weather_telemetry(*args, **kwargs):
    """Ingests regional 7-day weather telemetry forecasts."""
    regions = ['US_NORTHEAST', 'US_MIDWEST', 'US_SOUTHEAST', 'US_WEST', 'EU_WEST', 'EU_CENTRAL']
    records = []
    
    random.seed(44)
    for r in regions:
        for day in range(7):
            d = datetime.date.today() + datetime.timedelta(days=day)
            temp = round(random.uniform(28.0, 78.0), 1)
            temp_delta = round(temp - 55.0, 1)
            records.append({
                'forecast_date': str(d),
                'region_id': r,
                'avg_temp_f': temp,
                'temp_delta_baseline': temp_delta,
                'precipitation_in': round(random.uniform(0.0, 1.8), 2),
                'severe_weather_flag': random.random() < 0.15,
                'source_system': 'NOAA_WEATHER_API'
            })
    return pd.DataFrame(records)