import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_procurement_emails(*args, **kwargs):
    """Ingests unstructured supplier communication regarding delays and disruptions."""
    emails = [
        {
            'email_id': 'EML_20261013_001',
            'sender': 'operations@tsmc-logistics.com',
            'subject': 'Shipment Delay Notification - Semiconductor & Electronics Line',
            'body': 'Dear Procurement Team, due to unexpected customs clearance delays at Kaohsiung port, shipments for High-Velocity Electronics (HV_ELEC) will be delayed by approximately 8 business days. Please plan buffer inventories accordingly.',
            'cluster_hint': 'HV_ELEC'
        },
        {
            'email_id': 'EML_20261013_002',
            'sender': 'logistics@nordic-textiles.eu',
            'subject': 'Autumn Outerwear Production Update',
            'body': 'Notice: Seasonal Apparel (SEAS_APP) fabric dyeing bottleneck will delay winter parkas by 12 days. Confidence in mitigation is 0.92.',
            'cluster_hint': 'SEAS_APP'
        },
        {
            'email_id': 'EML_20261013_003',
            'sender': 'supply@bavarian-beverage.de',
            'subject': 'Glass Bottle Bottling Run Completion',
            'body': 'Beverage alcohol shipments are on schedule. Minor rail transit delay of 2 days expected into central logistics hubs.',
            'cluster_hint': 'BEV_ALCOHOL'
        }
    ]
    return pd.DataFrame(emails)