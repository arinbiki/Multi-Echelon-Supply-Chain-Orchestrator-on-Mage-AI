import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_fleet_capacity_matrix(*args, **kwargs):
    """Ingests fleet trailer capacity and pallet boundaries per distribution lane."""
    dcs = ['DC_US_EAST', 'DC_US_WEST', 'DC_EU_CENTRAL']
    data = []
    for dc in dcs:
        data.append({
            'dc_node': dc,
            'available_trailers': 35,
            'max_units_per_trailer': 1800,
            'trailer_volume_capacity_m3': 85.0,
            'trailer_payload_capacity_kg': 22000.0
        })
    return pd.DataFrame(data)