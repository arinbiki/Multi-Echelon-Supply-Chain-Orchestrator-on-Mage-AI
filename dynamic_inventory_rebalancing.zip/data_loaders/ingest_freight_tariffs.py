import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_freight_tariffs(*args, **kwargs):
    """Ingests transportation tariffs between distribution centers and stores."""
    dcs = ['DC_US_EAST', 'DC_US_WEST', 'DC_EU_CENTRAL']
    stores = [f'STORE_{i:03d}' for i in range(1, 21)]
    lanes = []
    for dc in dcs:
        for s in stores:
            dist = 180 + (int(s.split('_')[1]) * 35)
            rate_per_km = 1.85 if 'EAST' in dc else 1.95
            lanes.append({
                'source_node': dc,
                'dest_node': s,
                'distance_km': dist,
                'cost_per_transfer_unit': round(dist * 0.012 + 1.5, 3),
                'transit_hours': round(dist / 65.0, 1)
            })
    return pd.DataFrame(lanes)