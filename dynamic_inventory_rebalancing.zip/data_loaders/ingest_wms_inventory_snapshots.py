import datetime
import random
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_wms_inventory_snapshots(*args, **kwargs):
    """Ingests warehouse and retail store current on-hand and in-transit inventory."""
    clusters = [
        'HV_ELEC', 'SEAS_APP', 'GROC_PERISH', 'HOME_GOODS', 'AUTO_PARTS',
        'PHARMA_OTC', 'BEAUTY_PERS', 'BEV_ALCOHOL', 'OFFICE_SUPP', 'SPORT_OUTDOOR',
        'TOYS_HOBBY', 'PET_CARE', 'FURN_BED', 'BABY_CARE', 'HARDWARE_TOOL',
        'JEWEL_ACC', 'PACK_IND', 'FOOTWEAR', 'LUX_GOODS', 'GARDEN_PATIO',
        'DAIRY_PROD', 'FROZEN_FOODS', 'MEAT_SEAFOOD', 'PRODUCE_BULK', 'CLEAN_CHEM'
    ]
    nodes = ['DC_US_EAST', 'DC_US_WEST', 'DC_EU_CENTRAL'] + [f'STORE_{i:03d}' for i in range(1, 21)]
    records = []
    
    random.seed(43)
    for c in clusters:
        for n in nodes:
            is_dc = n.startswith('DC_')
            for sku_idx in range(1, 5):
                sku = f'SKU_{c}_{sku_idx:02d}'
                on_hand = random.randint(500, 4500) if is_dc else random.randint(20, 180)
                in_transit = random.randint(100, 800) if is_dc else random.randint(0, 40)
                reorder_point = 800 if is_dc else 45
                records.append({
                    'snapshot_date': str(datetime.date.today()),
                    'node_id': n,
                    'node_type': 'WAREHOUSE' if is_dc else 'RETAIL_STORE',
                    'cluster_id': c,
                    'sku': sku,
                    'on_hand_qty': on_hand,
                    'in_transit_qty': in_transit,
                    'reorder_point': reorder_point,
                    'source_system': 'WMS_SNAPSHOT_API'
                })
    return pd.DataFrame(records)