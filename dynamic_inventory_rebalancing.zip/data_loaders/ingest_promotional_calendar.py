import datetime
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_promotional_calendar(*args, **kwargs):
    """Ingests promotional campaigns and circular marketing events."""
    promos = [
        {'promo_id': 'PRM_FALL_ELEC', 'cluster_id': 'HV_ELEC', 'promo_type': 'FLASH_SALE', 'discount_pct': 18.0, 'active_days': 5},
        {'promo_id': 'PRM_WINTER_APP', 'cluster_id': 'SEAS_APP', 'promo_type': 'SEASONAL_LAUNCH', 'discount_pct': 25.0, 'active_days': 14},
        {'promo_id': 'PRM_HEALTH_OTC', 'cluster_id': 'PHARMA_OTC', 'promo_type': 'BUNDLE_OFFER', 'discount_pct': 10.0, 'active_days': 7},
        {'promo_id': 'PRM_BEV_HOLIDAY', 'cluster_id': 'BEV_ALCOHOL', 'promo_type': 'LOYALTY_EVENT', 'discount_pct': 15.0, 'active_days': 4},
        {'promo_id': 'PRM_HOME_COMFORT', 'cluster_id': 'HOME_GOODS', 'promo_type': 'CLEARANCE', 'discount_pct': 30.0, 'active_days': 10}
    ]
    return pd.DataFrame(promos)