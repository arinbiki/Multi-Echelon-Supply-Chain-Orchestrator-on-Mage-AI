import datetime
import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_macroeconomic_indicators(*args, **kwargs):
    """Ingests macroeconomic indicators including CPI and consumer confidence."""
    regions = ['US_NORTHEAST', 'US_MIDWEST', 'US_SOUTHEAST', 'US_WEST', 'EU_WEST', 'EU_CENTRAL']
    data = [
        {'region_id': r, 'cpi_index': 312.4 + i*0.8, 'consumer_confidence': 104.2 - i*1.1, 
         'inflation_rate_pct': 3.1 + i*0.1, 'disposable_income_growth_pct': 2.4, 
         'ingestion_date': str(datetime.date.today())}
        for i, r in enumerate(regions)
    ]
    return pd.DataFrame(data)