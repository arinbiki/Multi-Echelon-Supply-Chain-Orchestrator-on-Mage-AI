import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader

@data_loader
def load_store_metadata(*args, **kwargs):
    """Ingests store characteristics, footprints, and delivery constraints."""
    stores = []
    regions = ['US_NORTHEAST', 'US_MIDWEST', 'US_SOUTHEAST', 'US_WEST', 'EU_WEST', 'EU_CENTRAL']
    for i in range(1, 21):
        r = regions[(i - 1) % len(regions)]
        tier = 'TIER_1_FLAGSHIP' if i <= 5 else ('TIER_2_SUBURBAN' if i <= 15 else 'TIER_3_RURAL')
        stores.append({
            'store_id': f'STORE_{i:03d}',
            'region_id': r,
            'store_tier': tier,
            'sqft_capacity': 45000 if tier == 'TIER_1_FLAGSHIP' else 22000,
            'max_pallet_inbound_daily': 24 if tier == 'TIER_1_FLAGSHIP' else 12,
            'stockout_penalty_multiplier': 1.8 if tier == 'TIER_1_FLAGSHIP' else 1.2
        })
    return pd.DataFrame(stores)